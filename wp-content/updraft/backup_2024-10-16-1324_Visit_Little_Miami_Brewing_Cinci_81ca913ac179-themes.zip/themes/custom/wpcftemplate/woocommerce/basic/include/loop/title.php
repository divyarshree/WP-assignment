<?php
defined( 'ABSPATH' ) || exit;
?>
<h4 class="title"><a href="<?php  echo get_permalink(); ?> "><?php echo get_the_title(); ?></a></h4>
